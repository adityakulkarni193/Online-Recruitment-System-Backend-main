<h1><i>Recruitment System</i></h1>
  <p>The web application which make easier to find and fill the vacancies in companies.Enhanced from user as well as admin-end where job applying for user and adding jobs , shortlisting and scheduling interview task is far simple for admin.</p>  
  
  
  <h1><i>User Side</i></h1>
    
  <h2>Flow</h2>  
    <ul>
  <li>User can explore many jobs.</li>
  <li>Click on a job,he can see description about job,salary and location.</li>
  <li>On applying user have to fill the form.</li>
  
</ul>
    
    
    
    
    
  <h2><i>Home</i></h2>
    <p>Here, all jobs is visible to the user nearby posted by companies.</p>
    <img src = "https://user-images.githubusercontent.com/93570605/162711251-f24a367e-9657-409e-bf1b-18b9aafbab30.png"></img>
    <br/>
  <h2><i>Application Form</i></h2> 
  <p>It is required for the user to fill this form to apply for the job.</p>
  <h4>Personal Details</h4>
  User will fill personal detais here.
  <img src = "https://user-images.githubusercontent.com/93570605/162713126-e8e03363-6400-4a7a-af2e-feaf9b92c3f7.png"></img> 
  <br/>
    <h4>Professional Details</h4>
  <img src = "https://user-images.githubusercontent.com/93570605/162714016-a6ae5516-5083-4f9c-b10b-670a7d0a952b.png"></img>
  <br/></br>
  
   <h1><i>Admin Side</i></h1>
   
   <h2>Flow</h2>  
    <ul>
  <li>Admin should Logged in.</li>
  <li>All jobs posted by that admin can be visible by him.</li>
  <li>Who applied and show interest regarding the job can be visible on clicking that job.It will retreive the list of all interested candidates.</li>
  <li>Admin can shortlist if he liked the resume and can shedule the interview</li>
  <li>After interviewing admin can edit status about that applicant whether he passed or failed the interview.</li>
</ul>
   
   
   <h2><i>Home</i></h2>
   Admin will able to see the status of all the jobs posted by him.
    <img src = "https://user-images.githubusercontent.com/93570605/162715383-ca9ead67-7412-4230-8190-6a2349a30da9.png"></img>
    
   <h2><i>Admin Login</i></h2>
   Admin will put his credentials here.
   <img src = "https://user-images.githubusercontent.com/93570605/162716125-feb6965a-b1bf-43cc-a674-86f01ce1cbad.png"></img>
   
   <h2><i>Job Add Section</i></h2>
   Admin can add vacancies.
   <img src = "https://user-images.githubusercontent.com/93570605/162718448-1c40a9a8-cb27-44f9-bb57-87d0eed99878.png"></img>
   
   <h2><i>Shortlist Section</i></h2>
   Here all applicants are visible who are shortlisted visible and after click on that applicant admin can see below one.
   <img src = "https://user-images.githubusercontent.com/93570605/162720783-dc4bbb84-c726-4966-a28f-c544b5ec4ea6.png"></img>
   
   Here admin can schedule the interview for selected applicants.
   <img src = "https://user-images.githubusercontent.com/93570605/162720855-6117e54b-9a97-4ffb-bfbf-1347f17e4dfb.png"></img>
   
   <h2><i>Interview Section</i></h2>
   All applicants who are selected for the interview visible here.On clicking at one,it will show the status set page.(below)
   <img src = "https://user-images.githubusercontent.com/93570605/162722112-837e1fc6-ea00-4bde-b37b-14bb0efe730e.png"></img>
   <br/>
   Applicant's status can be update here whether she/he is hired or not.
   <img src = "https://user-images.githubusercontent.com/93570605/162722184-f0cbe20a-a6c7-468d-9243-50a4cac05a12.png"></img>
   


