export const API = "https://recruitment-backend-app.herokuapp.com";
// export const API = "http://localhost:8050";
