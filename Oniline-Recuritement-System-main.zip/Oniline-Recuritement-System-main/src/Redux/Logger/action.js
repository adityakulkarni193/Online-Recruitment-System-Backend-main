// action type
export const IS_LOGIN = "IS_LOGIN";

// action-creator
export const isLogin = (obj) => ({ type: IS_LOGIN, payload: obj });
