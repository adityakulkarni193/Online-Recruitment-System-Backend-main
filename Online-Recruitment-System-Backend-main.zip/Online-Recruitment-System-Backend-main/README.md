# Recruitment-system-backend
Backend API for a Recruitment system, built using NodeJS, Express, Mongoose, MongoDB Atlas for storage and Heroku for Deployment
